# TravelGo

A responsive, Bootstrap 5.3.8 travel-booking website prototype built with HTML, CSS and vanilla JavaScript.

## Pages

- `index.html` — flight search
- `results.html` — sample flight results
- `booking.html` — passenger details and fare summary
- `ticket.htm` — demo ticket and print view
- `trains.html` — train search demo
- `buses.html` — bus search demo
- `hotels.html` — hotel search and sample listings
- `holiday.html` — holiday package cards
- `style.css` — shared theme and responsive styling

## Run locally

1. Download or clone this repository.
2. Open the folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.

No build process or package installation is required. Bootstrap CSS and JavaScript are loaded from the jsDelivr CDN, so an internet connection is needed for Bootstrap styling and responsive navigation.

## Flight demo flow

`index.html` → `results.html` → `booking.html` → `ticket.htm`

The search and passenger information are passed between pages through URL query parameters. The flight, fare, train/bus results, hotel listings and package selections are sample demonstration data only.

## Important limitations

This is a front-end college project prototype. It does not connect to live airline/train/bus inventory, hotel booking systems, user accounts, databases or payment gateways. No real booking or payment is made.

## GitHub upload

Create a new GitHub repository, then upload the contents of this folder. Keep all HTML files and `style.css` together in the same root folder so the relative links continue to work.
